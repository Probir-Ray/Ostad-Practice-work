const foodItems = [
  { id: 1, name: "Rice", price: 68 },
  { id: 2, name: "Potato", price: 30 },
  { id: 3, name: "Onion", price: 50 },
  { id: 4, name: "Egg", price: 10 },
  { id: 5, name: "Cheese", price: 730 },
  { id: 6, name: "Milk", price: 85 },
  { id: 7, name: "Atta", price: 82 },
];

export { foodItems };
