const express = require("express");
const { helloGet, greeting } = require("../controllers/HelloController");
const router = express.Router();

router.get("/get-msg", helloGet);
router.post("/greeting-msg", greeting);

module.exports = router;
